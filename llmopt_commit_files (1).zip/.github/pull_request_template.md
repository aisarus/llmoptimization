# Context
Full-repo first-pass review request.

## Focus areas
- Correctness & edge cases
- Complexity & naming
- Tests coverage
- Public API clarity

## Checklist
- [ ] Builds locally
- [ ] Tests pass
