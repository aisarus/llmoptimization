# __main__.py
# Entry point

from cost import estimate_cost
from text_stats import count_words, count_chars

if __name__ == "__main__":
    sample = "Hello world from EFM project"
    print("Words:", count_words(sample))
    print("Chars:", count_chars(sample))
    print("Cost:", estimate_cost(1200, 0.002))
