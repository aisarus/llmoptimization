# text_stats.py
# Fixed filename without suffix numbers

def count_words(text: str) -> int:
    return len(text.split())

def count_chars(text: str) -> int:
    return len(text)
