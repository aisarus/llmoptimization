# cost.py
# Fixed filename without spaces or parentheses

def estimate_cost(tokens: int, price_per_1k: float) -> float:
    return (tokens / 1000) * price_per_1k
